import { getRandomTextValues } from './Fields/text';
import { getRandomBooleanValues } from './Fields/boolean';
import { getRandomAddressComponents } from './Fields/address';
import { getRandomDate, getRandomTime, getRandomDateTime } from './Fields/datetime'; 

interface Field {
    name: string;
    Type: string;
    values?: string[]; // Optional for 'custom' type
}

interface Input {
    SObject?: string;
    Count?: number;
    Language?: string;
    exclude: string[];
    Fields: Field[];
}

function filterFields(input: Input) {
    const excludeSet = new Set(input.exclude);
    return input.Fields.filter((field) => !excludeSet.has(field.name));
}

function preGenerateValuesForField(field: Field, count: number): any[] {
    switch (field.Type) {
        case 'text':
            return getRandomTextValues(field.name, count);
        case 'boolean':
            return getRandomBooleanValues(count);
        case 'address':
            return getRandomAddressComponents(count);
        case 'date':
            return Array(count).fill(null).map(() => getRandomDate(new Date(2000, 0, 1), new Date()));
        case 'time':
            return Array(count).fill(null).map(() => getRandomTime());
        case 'datetime':
            return Array(count).fill(null).map(() => getRandomDateTime(new Date(2000, 0, 1), new Date()));
        case 'custom':
            if (field.values && field.values.length > 0) {
                return Array(count).fill(null).map(() => field.values![Math.floor(Math.random() * field.values!.length)]);
            }
            return [];
        default:
            return [];
    }
}

function extractAddressPrefix(fieldName: string): string | null {
    const match = fieldName.match(/^(Billing|Shipping|Other)(Street|City|State|PostalCode|Country)$/);
    return match ? match[1] : null;
}

export function generateRecords(input: Input): Array<Record<string, any>> {
    const filteredFields = filterFields(input);
    const recordCount = input.Count || 1;
    const preGeneratedValues: Record<string, any[]> = {};

    filteredFields.forEach(field => {
        const addressPrefix = extractAddressPrefix(field.name);
        if (addressPrefix) {
            preGeneratedValues[addressPrefix] = preGenerateValuesForField({ name: addressPrefix, Type: 'address' }, recordCount);
        } else {
            preGeneratedValues[field.name] = preGenerateValuesForField(field, recordCount);
        }
    });

    const records = [];

    for (let i = 0; i < recordCount; i++) {
        const record: Record<string, any> = {};

        filteredFields.forEach(field => {
            const addressPrefix = extractAddressPrefix(field.name);
            if (addressPrefix) {
                const addressIndex = i % preGeneratedValues[addressPrefix].length;
                const addressPart = field.name.split(addressPrefix)[1].replace(/^\/?/, '');
                if (addressPart === 'Street') {
                    record[field.name] = preGeneratedValues[addressPrefix][addressIndex].street;
                } else if (addressPart === 'City') {
                    record[field.name] = preGeneratedValues[addressPrefix][addressIndex].city;
                } else if (addressPart === 'State') {
                    record[field.name] = preGeneratedValues[addressPrefix][addressIndex].state;
                } else if (addressPart === 'PostalCode') {
                    record[field.name] = preGeneratedValues[addressPrefix][addressIndex].postalCode;
                } else if (addressPart === 'Country') {
                    record[field.name] = preGeneratedValues[addressPrefix][addressIndex].country;
                }
            } else {
                record[field.name] = preGeneratedValues[field.name][i];
            }
        });

        records.push(record);
    }

    return records;
}
