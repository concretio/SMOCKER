const valuesByField : Record<string, string[]> = {
    FirstName: [
        '晴人',    // Haruto
        '優斗',    // Yuto
        '蒼太',    // Sota
        '陸',      // Riku
        '幸',      // Yuki
        '海斗',    // Kaito
        '桜',      // Sakura
        '日向',    // Hinata
        '結愛',    // Yua
        '梨奈',    // Rina
        '唯',      // Yui
        'ひな',    // Hina
        '美空',    // Miku
        '美緒',    // Mio
        '蒼井',    // Aoi
        '加奈',    // Kana
        '優奈',    // Yuna
        '理子',    // Riko
        '奈々',    // Nana
        '直',      // Nao
        '翔太',    // Shota
        '蓮',      // Ren
        '智',      // Tomo
        '海',      // Kai
        '空',      // Sora
        '亮',      // Ryo
        '健太',    // Kenta
        '拓',      // Taku
        '大輝'     // Daiki
    ],
    LastName: [
        '田中',    // Tanaka
        '鈴木',    // Suzuki
        '高橋',    // Takahashi
        '山本',    // Yamamoto
        '小林',    // Kobayashi
        '松本',    // Matsumoto
        '井上',    // Inoue
        '金子',    // Kaneko
        '斎藤',    // Saito
        '藤田',    // Fujita
        '吉田',    // Yoshida
        '伊藤',    // Ito
        '渡辺',    // Watanabe
        '加藤',    // Kato
        '中村',    // Nakamura
        '黒沢',    // Kurosawa
        '宮本',    // Miyamoto
        '武田',    // Takeda
        '小川',    // Ogawa
        '清水',    // Shimizu
        '岸田',    // Kishida
        '坂本',    // Sakamoto
        '宮崎',    // Miyazaki
        '長谷川',  // Hasegawa
        '原',      // Hara
        '岡田',    // Okada
        '斎藤',    // Saito
        '小林',    // Kobayashi
        '平田'     // Hirata
    ]
};

export function getRandomTextValues(field: string, count: number) {
    const values = valuesByField[field] || [];
    const shuffled = values.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
}
