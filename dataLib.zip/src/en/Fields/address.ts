interface City {
    city: string;
    postalCode: string;
    street: string;
}

interface State {
    [stateName: string]: City[];
}

interface Country {
    country: string;
    states: State;
}

interface AddressPool {
    [countryCode: string]: Country;
}


const addressPool: AddressPool = {
    "IN": {
        country: "India",
        states: {
            "Rajasthan": [
                {
                    city: "Jodhpur",
                    postalCode: "342008",
                    street: "C-121, Shankar Nagar, Pipli Chauraha"
                }
            ],
            "Maharashtra": [
                {
                    city: "Mumbai",
                    postalCode: "400001",
                    street: "221B, Baker Street, Colaba"
                }
            ],
            "Delhi": [
                {
                    city: "New Delhi",
                    postalCode: "110001",
                    street: "45, Ashoka Road, Connaught Place"
                }
            ],
            "Karnataka": [
                {
                    city: "Bangalore",
                    postalCode: "560001",
                    street: "12, MG Road, Brigade Road Junction"
                }
            ]
        }
    },
    "US": {
        country: "United States",
        states: {
            "NY": [
                {
                    city: "New York",
                    postalCode: "10001",
                    street: "350 5th Ave, Empire State Building"
                }
            ],
            "California": [
                {
                    city: "San Francisco",
                    postalCode: "94103",
                    street: "1 Market St, Spear Tower"
                }
            ]
        }
    },
    "UK": {
        country: "United Kingdom",
        states: {
            "Greater London": [
                {
                    city: "London",
                    postalCode: "EC1A 1BB",
                    street: "221B Baker Street, Marylebone"
                }
            ]
        }
    },
    "FR": {
        country: "France",
        states: {
            "Ile-de-France": [
                {
                    city: "Paris",
                    postalCode: "75001",
                    street: "8 Rue de Rivoli, 1st Arrondissement"
                }
            ]
        }
    },
    "DE": {
        country: "Germany",
        states: {
            "Berlin": [
                {
                    city: "Berlin",
                    postalCode: "10115",
                    street: "Unter den Linden, Mitte"
                }
            ]
        }
    },
    "JP": {
        country: "Japan",
        states: {
            "Tokyo Metropolis": [
                {
                    city: "Tokyo",
                    postalCode: "100-0001",
                    street: "Chiyoda-ku, 1-1 Chiyoda"
                }
            ]
        }
    },
    "AU": {
        country: "Australia",
        states: {
            "New South Wales": [
                {
                    city: "Sydney",
                    postalCode: "2000",
                    street: "1 Macquarie St, Circular Quay"
                }
            ]
        }
    },
    "CA": {
        country: "Canada",
        states: {
            "Ontario": [
                {
                    city: "Toronto",
                    postalCode: "M5H 2N2",
                    street: "100 King St W, Financial District"
                }
            ]
        }
    },
    "AE": {
        country: "United Arab Emirates",
        states: {
            "Dubai Emirate": [
                {
                    city: "Dubai",
                    postalCode: "00000",
                    street: "1 Sheikh Mohammed bin Rashid Blvd, Downtown"
                }
            ]
        }
    },
    "ZA": {
        country: "South Africa",
        states: {
            "Western Cape": [
                {
                    city: "Cape Town",
                    postalCode: "8001",
                    street: "1 Dock Rd, V&A Waterfront"
                }
            ]
        }
    },
    "BR": {
        country: "Brazil",
        states: {
            "São Paulo": [
                {
                    city: "São Paulo",
                    postalCode: "01000-000",
                    street: "Av. Paulista, Bela Vista"
                }
            ]
        }
    }
};

export function getRandomAddressComponents(count: number) {
    const addresses = [];
    const countries = Object.keys(addressPool);
    
    for (let i = 0; i < count; i++) {
        const countryKey = countries[Math.floor(Math.random() * countries.length)];
        const country = addressPool[countryKey];
        const states = Object.keys(country.states);
        const stateKey = states[Math.floor(Math.random() * states.length)];
        const state = country.states[stateKey];
        const city = state[Math.floor(Math.random() * state.length)];
        
        addresses.push({
            country: country.country,
            state: stateKey,
            city: city.city,
            postalCode: city.postalCode,
            street: city.street
        });
    }
    
    return addresses;
}
