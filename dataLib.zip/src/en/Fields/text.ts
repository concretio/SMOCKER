const valuesByField: Record<string, string[]> = {
    FirstName: [
        'Akshat',
        'Divy',
        'Kunal',
        'Yash',
        'Aarav',
        'Vivaan',
        'Aditya',
        'Aryan',
        'Krishna',
        'Kabir',
        'Liam',
        'Noah',
        'Olivia',
        'Emma',
        'Ava',
        'Isabella',
        'Sophia',
        'Mia',
        'Amelia',
        'Lucas',
        'Mateo',
        'Sebastian',
        'Santiago',
        'José',
        'Lucia',
        'Martina',
        'Sofia',
        'Hugo',
        'Leo',
        'Carlos'
    ],
    LastName: [
        'Laddha',
        'Vishanani',
        'Surana',
        'Muni',
        'Sharma',
        'Gupta',
        'Verma',
        'Kapoor',
        'Mehra',
        'Bajaj',
        'Smith',
        'Johnson',
        'Williams',
        'Brown',
        'Jones',
        'Garcia',
        'Miller',
        'Davis',
        'Rodriguez',
        'Martinez',
        'Lopez',
        'Gonzalez',
        'Perez',
        'Sanchez',
        'Ramirez',
        'Hernandez',
        'Fernandez',
        'Mueller',
        'Schmidt',
        'Weber'
    ]
};

export function getRandomTextValues(field: string, count: number): string[] {
    const values = valuesByField[field] || [];
    const shuffled = values.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
}

