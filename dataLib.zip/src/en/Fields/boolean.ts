export function getRandomBooleanValues(count: number): boolean[] {
    const booleanArray: boolean[] = [];
    for (let i = 0; i < count; i++) {
        booleanArray.push(Math.random() >= 0.5);
    }
    return booleanArray;
}
