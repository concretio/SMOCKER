async function main() {
    let generateRecords;

    const testInput = {
        SObject: "Account",
        Language: "en",
        exclude: ["Department", "Gender", "LastModifiedDatetime"],
        Fields: [
            { name: "FirstName", Type: "text" },
            { name: "LastName", Type: "text" },
            { name: "IsActive", Type: "boolean" },
            { name: "BillingStreet", Type: "address" },
            { name: "BillingCity", Type: "address" },
            { name: "BillingState", Type: "address" },
            { name: "BillingPostalCode", Type: "address" },
            { name: "BillingCountry", Type: "address" },
            { name: "ShippingStreet", Type: "address" },
            { name: "ShippingCity", Type: "address" },
            { name: "ShippingState", Type: "address" },
            { name: "ShippingPostalCode", Type: "address" },
            { name: "ShippingCountry", Type: "address" },
            { name: "CreatedDate", Type: "date" },
            { name: "LastLoginTime", Type: "time" },
            { name: "LastModifiedDatetime", Type: "datetime" },
            { name: "CustomField", Type: "custom", values: ["one", "two", "three"] }
        ]
    };

    if (testInput.Language === 'en') {
        const { generateRecords: genEn } = await import(`./en/gen`);
        generateRecords = genEn;
    } else if (testInput.Language === 'jp') {
        const { generateRecords: genJp } = await import(`./jp/genjp`);
        generateRecords = genJp;
    } else {
        throw new Error(`Unsupported language`);
    }

    const records = await generateRecords(testInput);
    console.log(records);
}

main().catch((error) => {
    console.error("An error occurred:", error);
});